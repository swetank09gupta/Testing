package com.example.auction.user.api;

import lombok.Value;

@Value
public final class UserLogin {

    private final String email;
    private final String password;



}
