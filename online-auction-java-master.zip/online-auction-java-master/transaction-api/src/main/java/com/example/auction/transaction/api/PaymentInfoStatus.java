package com.example.auction.transaction.api;

public enum PaymentInfoStatus {
    APPROVED,
    REJECTED
}
