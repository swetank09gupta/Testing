package com.example.auction.transaction.impl;

public enum PaymentStatus {
    APPROVED,
    REJECTED
}
