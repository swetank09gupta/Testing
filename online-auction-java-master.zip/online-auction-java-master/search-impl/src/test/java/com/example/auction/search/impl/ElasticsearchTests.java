package com.example.auction.search.impl;

public interface ElasticsearchTests {
}
