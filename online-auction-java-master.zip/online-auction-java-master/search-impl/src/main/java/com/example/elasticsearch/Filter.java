package com.example.elasticsearch;


public interface Filter {

}
